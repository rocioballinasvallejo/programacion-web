function openVideo(videoSource) {
    const videoModal = document.getElementById("video-modal");
    const modalVideo = document.getElementById("modal-video");

    modalVideo.src = videoSource;
    videoModal.style.display = "flex";
    modalVideo.style.display = "block"; 
  }

  function closeVideoModal() {
    const videoModal = document.getElementById("video-modal");
    const modalVideo = document.getElementById("modal-video");

    modalVideo.pause();
    modalVideo.src = "";
    videoModal.style.display = "none";
    modalVideo.style.display = "none";
  }